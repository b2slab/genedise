#ifndef DO_PLMRMA_H
#define  DO_PLMRMA_H

#include "common_types.h"


void do_PLMrma(Datagroup *data,  PLMmodelparam *model, PLMoutput *output, outputsettings *store);


#endif

