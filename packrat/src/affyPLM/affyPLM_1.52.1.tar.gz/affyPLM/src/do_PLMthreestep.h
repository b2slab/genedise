#ifndef DO_PLMTHREESTEP_H
#define DO_PLMTHREESTEP_H 1


#include "common_types.h"

void do_PLMthreestep(Datagroup *data,  PLMmodelparam *model, PLMoutput *output, outputsettings *store);

#endif
