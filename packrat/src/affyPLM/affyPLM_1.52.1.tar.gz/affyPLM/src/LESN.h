#ifndef LESH_H
#define LESN_H 1

void LESN_correct(double *data, int rows, int cols, int method, double baseline, double theta);


#endif
