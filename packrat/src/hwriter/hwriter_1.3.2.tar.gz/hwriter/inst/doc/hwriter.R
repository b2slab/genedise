### R code from vignette source 'hwriter.Rnw'

###################################################
### code chunk number 1: example
###################################################
library('hwriter')
example('hwriter')


