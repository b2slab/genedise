## ----style-knitr, eval=TRUE, echo=FALSE, results="asis"---------------------------------
BiocStyle::latex()

## ----Loading, eval=TRUE, echo = TRUE----------------------------------------------------
    library(BeadDataPackR)
    dataPath <- system.file("extdata", package = "BeadDataPackR")

## ----Compress, eval=FALSE, echo = TRUE--------------------------------------------------
#      compressBeadData(txtFile = "example.txt", locsGrn = "example_Grn.locs",
#                       outputFile = "example.bab", path = dataPath, nBytes = 4,
#                       nrow = 326, ncol = 4)

## ----Decompress, eval=FALSE-------------------------------------------------------------
#      decompressBeadData(inputFile = "example.bab", inputPath = dataPath,
#                         outputMask = "restored", outputPath = ".",
#                         outputNonDecoded = FALSE, roundValues = TRUE )

## ----readCompressed, eval = FALSE-------------------------------------------------------
#    readCompressedData(inputFile = "example.bab", path = dataPath, probeIDs = c(10008, 10010) )

## ----extractLocsFile, eval = FALSE------------------------------------------------------
#    locs <- extractLocsFile(inputFile = "example.bab", path = dataPath)

## ----sessionInfo, results='asis', eval=TRUE---------------------------------------------
toLatex(sessionInfo())

