## ----knitr, echo=FALSE, results="hide"-----------------------------------
library("knitr")
opts_chunk$set(tidy=FALSE,dev="png",fig.show="as.is",
               fig.width=10,fig.height=6,
               message=FALSE,eval=T,warning=FALSE)

## ----style, eval=TRUE, echo=F, results="asis"-------------------------------------------
BiocStyle::latex()

## ----Help, eval=FALSE-------------------------------------------------------------------
#  library("beadarray")
#  beadarrayUsersGuide(topic="beadlevel")
#  beadarrayUsersGuide(topic="beadsummary")

## ----NEWS, eval=FALSE, echo=TRUE--------------------------------------------------------
#  news(package="beadarray")

## ----CompanionPkg,eval=FALSE------------------------------------------------------------
#  
#  source("http://www.bioconductor.org/biocLite.R")
#  
#  biocLite(c("beadarrayExampleData", "beadarrayExampleData"))
#  

## ----Mailing list-----------------------------------------------------------------------
sessionInfo()

