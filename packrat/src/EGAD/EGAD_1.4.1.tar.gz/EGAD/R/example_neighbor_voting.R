#' @name example_neighbor_voting
#' @title Example of binary network  
#'
#' @description
#' This dataset includes 
#'
#' @docType data

#' @format 
#' \describe{
#'   \item{entrezID}{chromosomal start position, in base pairs}
#'   \item{name}{HUGO gene identifier}
#'   \item{species}{species}
#'   \item{disease}{disease}
#'  
#' }

#' @rdname example_neighbor_voting
#'
NULL