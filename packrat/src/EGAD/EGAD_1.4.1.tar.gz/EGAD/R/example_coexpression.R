#' @name example_coexpression
#' @title Example of binary network  
#'
#' @description
#' This dataset includes 
#'
#' @docType data
#' @format Matrices and vectors
#'
#' @rdname example_coexpression
#'
NULL