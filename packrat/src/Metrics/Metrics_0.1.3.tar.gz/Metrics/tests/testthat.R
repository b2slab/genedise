library(testthat)
library(Metrics)

testthat::test_check("Metrics")