

setGeneric("as.list")

