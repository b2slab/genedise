#
# A simple barplot() is just the boxes and the axes.
# The first <g> element within the body of the SVG
# content (i.e. after the <defs> node and within the <g id="surface0">)
# is the container for the boxes within the plot region of the barplot.

if(FALSE) {

}
