useCairoPkg = FALSE
svgFun = svg
cairoVersion = "1.10.2"
isCairoVersion10OrMore = 1

