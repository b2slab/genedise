var x = 1;
var y;
y = ++x;
alert("Hi you" + y + " " + x);

var z = 2.0;

//alert( z ===  x);

x = if(y > 2) 3 else 10;
//alert(x);
