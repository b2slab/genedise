BiocGenerics:::testPackage("GEOquery")
