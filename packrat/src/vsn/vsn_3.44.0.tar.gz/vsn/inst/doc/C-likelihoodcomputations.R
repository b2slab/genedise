### R code from vignette source 'C-likelihoodcomputations.Rnw'

###################################################
### code chunk number 1: style-Sweave
###################################################
BiocStyle::latex2()


